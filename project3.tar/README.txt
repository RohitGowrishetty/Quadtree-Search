-------------------------------------------------
- README file for the Project 3
- Contributors: Rohit Kumar Gowrishetty, Venkata Shashank Kalki, Zhicheng Liang
- Date: 07-25-2016
-------------------------------------------------

Getting started
----------------
  Project 3 aims at construction of Quadtree and Point search in GPU.
  Our final result consists of performance achieved by a CPU algorithm and optimized GPU code. 
   
Further README contents
-----------------------
  1. Minimun System Requirement
  2. Included files
  3. Execute & Clean

1. Minimun System Requirement
-------------------------
	Nvidia graphics card
	CUDA 7.5 complier

2. Included files
------------------
  README.txt                 - This README file
  Report.pdf                 - Description about the project 3.
  cpu.cu  		     - Source file logics to measure CPU perfomance.
  gpu.cu  		     - Source file logics to measure GPU performance.
  Makefile                   - Makefile providing 'executable' and 'clean' targets

3. Execute & Clean
------------------

To compile and generate the executable file run:

  make

To run the program

  CPU Logic : ./cpu <numSearchPoints>
  GPU Logic : ./gpu <blockSize> <numSearchPoints>

To remove the executable and object files

  make clean


4. Output 
----------
In the report we included the best time readings we achieved for 10 lakh search points is as below
 
Single threaded CPU code - 39.54 seconds

Optimised GPU algorithm	 - 0.092 seconds

Note: During the time of execution, in CPU we need to give search points as argument, in GPU we need
to provide blocksize and search points as arguement in the same order.